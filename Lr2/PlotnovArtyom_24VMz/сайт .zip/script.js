function showTab(tabName) {
    const tabs = document.getElementsByClassName('tab');
    for (let i = 0; i < tabs.length; i++) {
        tabs[i].style.display = 'none';
    }
    document.getElementById(tabName).style.display = 'block';
    highlightLowestPrices();
}

function highlightLowestPrices() {
    const tables = document.querySelectorAll("table");
    tables.forEach(table => {
        const rows = table.querySelectorAll("tr:not(:first-child)");
        rows.forEach(row => {
            const cells = Array.from(row.querySelectorAll("td"));
            const prices = cells.slice(1).map(td => parseFloat(td.textContent));
            const minPrice = Math.min(...prices);
            cells.forEach((td, index) => {
                td.classList.remove("lowest");
                if (index > 0 && parseFloat(td.textContent) === minPrice) {
                    td.classList.add("lowest");
                }
            });
        });
    });
}

// Показываем первую вкладку по умолчанию
showTab('vegetables');
